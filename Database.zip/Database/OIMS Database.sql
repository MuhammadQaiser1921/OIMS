-- =============================================
-- Oradigitals Internal Management System (OIMS)
-- MySQL Database Schema with Sample Data
-- =============================================

-- Create Database (Drop if exists to avoid errors)
DROP DATABASE IF EXISTS oims_db;
CREATE DATABASE oims_db;
USE oims_db;

-- =============================================
-- 1. USERS TABLE (Authentication & Roles)
-- =============================================
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('super_admin', 'hr_manager', 'finance_manager', 'project_manager') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- 2. EMPLOYEES TABLE
-- =============================================
DROP TABLE IF EXISTS employees;
CREATE TABLE employees (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    cnic VARCHAR(15),
    address TEXT,
    salary DECIMAL(10,2) NOT NULL,
    bank_account VARCHAR(50),
    hire_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- 3. CLIENTS TABLE
-- =============================================
DROP TABLE IF EXISTS clients;
CREATE TABLE clients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    company VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    whatsapp VARCHAR(20),
    address TEXT,
    city VARCHAR(50),
    country VARCHAR(50) DEFAULT 'Pakistan',
    contract_file VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================
-- 4. PROJECTS TABLE
-- =============================================
DROP TABLE IF EXISTS projects;
CREATE TABLE projects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    client_id INT NOT NULL,
    start_date DATE,
    end_date DATE,
    status ENUM('ongoing', 'completed', 'on_hold', 'cancelled') DEFAULT 'ongoing',
    budget DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

-- =============================================
-- 5. PROJECT ASSIGNMENTS TABLE
-- =============================================
DROP TABLE IF EXISTS project_assignments;
CREATE TABLE project_assignments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    employee_id INT NOT NULL,
    assigned_date DATE DEFAULT (CURRENT_DATE),
    role_in_project VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY unique_assignment (project_id, employee_id)
);

-- =============================================
-- 6. PAYMENTS TABLE
-- =============================================
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    client_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('cash', 'bank_transfer', 'jazzcash', 'easypaisa', 'paypal', 'stripe', 'cheque') NOT NULL,
    payment_status ENUM('paid', 'partial', 'unpaid') DEFAULT 'unpaid',
    reference_number VARCHAR(100),
    invoice_file VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
);

-- =============================================
-- 7. EXPENSES TABLE
-- =============================================
DROP TABLE IF EXISTS expenses;
CREATE TABLE expenses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category ENUM('utilities', 'marketing', 'software', 'office_supplies', 'transport', 'internet', 'rent', 'food', 'equipment', 'miscellaneous') NOT NULL,
    description TEXT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    expense_date DATE NOT NULL,
    payment_method ENUM('cash', 'bank_transfer', 'jazzcash', 'easypaisa', 'card', 'cheque') NOT NULL,
    receipt_file VARCHAR(255),
    approved_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
);

-- =============================================
-- 8. SALARY PAYMENTS TABLE
-- =============================================
DROP TABLE IF EXISTS salary_payments;
CREATE TABLE salary_payments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT NOT NULL,
    salary_month INT NOT NULL CHECK (salary_month BETWEEN 1 AND 12),
    salary_year INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('cash', 'bank_transfer', 'jazzcash', 'easypaisa', 'cheque') NOT NULL,
    reference_number VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    UNIQUE KEY unique_salary (employee_id, salary_month, salary_year)
);

-- =============================================
-- INSERT SAMPLE DATA
-- =============================================

-- Insert Users (System Administrators)
INSERT INTO users (username, email, password_hash, role) VALUES
('admin', 'admin@oradigitals.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/lewf5aWNRN1wh5CiW', 'super_admin'),
('hr_manager', 'hr@oradigitals.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/lewf5aWNRN1wh5CiW', 'hr_manager'),
('finance_manager', 'finance@oradigitals.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/lewf5aWNRN1wh5CiW', 'finance_manager'),
('project_manager', 'pm@oradigitals.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/lewf5aWNRN1wh5CiW', 'project_manager');

-- Insert Employees (Pakistani Names & Context)
INSERT INTO employees (employee_id, name, designation, email, phone, cnic, address, salary, bank_account, hire_date) VALUES
('EMP001', 'Noor Malik', 'Senior Developer', 'noor@oradigitals.com', '+92-300-1234567', '42101-1234567-8', 'Block A, Johar Town, Lahore', 85000.00, '01234567890123', '2023-01-15'),
('EMP002', 'Fatima Sheikh', 'UI/UX Designer', 'fatima@oradigitals.com', '+92-321-9876543', '42201-9876543-2', 'DHA Phase 2, Islamabad', 65000.00, '01234567890124', '2023-02-20'),
('EMP003', 'Ali Hassan', 'Project Manager', 'ali@oradigitals.com', '+92-333-5555555', '42301-5555555-5', 'Gulberg III, Lahore', 95000.00, '01234567890125', '2023-03-10'),
('EMP004', 'Ayesha Malik', 'Digital Marketing Specialist', 'ayesha@oradigitals.com', '+92-315-7777777', '42401-7777777-7', 'F-10 Markaz, Islamabad', 55000.00, '01234567890126', '2023-04-05'),
('EMP005', 'Hassan Raza', 'Backend Developer', 'hassan@oradigitals.com', '+92-302-8888888', '42501-8888888-8', 'Model Town, Lahore', 75000.00, '01234567890127', '2023-05-12'),
('EMP006', 'Zainab Qureshi', 'HR Manager', 'zainab@oradigitals.com', '+92-331-9999999', '42601-9999999-9', 'Bahria Town, Rawalpindi', 80000.00, '01234567890128', '2023-06-18'),
('EMP007', 'Umar Farooq', 'Quality Assurance', 'umar@oradigitals.com', '+92-345-1111111', '42701-1111111-1', 'Satellite Town, Rawalpindi', 60000.00, '01234567890129', '2023-07-22'),
('EMP008', 'Sana Afridi', 'Content Writer', 'sana@oradigitals.com', '+92-316-2222222', '42801-2222222-2', 'University Town, Peshawar', 45000.00, '01234567890130', '2023-08-15');

-- Insert Clients
INSERT INTO clients (name, company, email, phone, whatsapp, address, city, country) VALUES
('Tariq Ahmed', 'Tech Solutions Ltd', 'tariq@techsolutions.pk', '+92-42-35123456', '+92-300-1111111', 'Main Boulevard, Gulberg, Lahore', 'Lahore', 'Pakistan'),
('Sarah Khan', 'Digital Marketing Hub', 'sarah@dmhub.com', '+92-51-2345678', '+92-321-2222222', 'Blue Area, Islamabad', 'Islamabad', 'Pakistan'),
('Imran Malik', 'E-Commerce Solutions', 'imran@ecomsol.pk', '+92-21-87654321', '+92-333-3333333', 'Clifton Block 2, Karachi', 'Karachi', 'Pakistan'),
('Nadia Hussain', 'Healthcare Systems', 'nadia@healthsys.pk', '+92-42-98765432', '+92-315-4444444', 'DHA Phase 5, Lahore', 'Lahore', 'Pakistan'),
('Faisal Riaz', 'Educational Services', 'faisal@edusrv.pk', '+92-91-1234567', '+92-345-5555555', 'University Road, Peshawar', 'Peshawar', 'Pakistan'),
('Amna Siddiqui', 'Fashion Retail', 'amna@fashionret.pk', '+92-21-5555555', '+92-302-6666666', 'Saddar Town, Karachi', 'Karachi', 'Pakistan');

-- Insert Projects
INSERT INTO projects (title, description, client_id, start_date, end_date, status, budget) VALUES
('E-Commerce Website Development', 'Complete online store with payment gateway integration', 1, '2024-01-15', '2024-03-15', 'completed', 350000.00),
('Digital Marketing Campaign', 'Social media marketing and SEO optimization', 2, '2024-02-01', '2024-04-30', 'ongoing', 150000.00),
('Mobile App Development', 'Cross-platform mobile application for inventory management', 3, '2024-03-01', '2024-06-30', 'ongoing', 500000.00),
('Hospital Management System', 'Complete web-based HMS with patient records', 4, '2024-01-20', '2024-05-20', 'ongoing', 750000.00),
('School Management Portal', 'Student information system with online fee payment', 5, '2024-04-01', '2024-07-31', 'ongoing', 400000.00),
('Fashion Website Redesign', 'Complete UI/UX overhaul and responsive design', 6, '2024-02-15', '2024-04-15', 'completed', 200000.00);

-- Insert Project Assignments
INSERT INTO project_assignments (project_id, employee_id, role_in_project) VALUES
(1, 1, 'Lead Developer'),
(1, 2, 'UI Designer'),
(1, 3, 'Project Manager'),
(2, 4, 'Marketing Lead'),
(2, 8, 'Content Writer'),
(3, 1, 'Senior Developer'),
(3, 5, 'Backend Developer'),
(3, 7, 'QA Tester'),
(4, 5, 'Lead Backend Developer'),
(4, 2, 'UI/UX Designer'),
(4, 3, 'Project Manager'),
(5, 1, 'Full Stack Developer'),
(5, 8, 'Content Writer'),
(6, 2, 'Lead Designer'),
(6, 4, 'Marketing Consultant');

-- Insert Payments
INSERT INTO payments (project_id, client_id, amount, payment_date, payment_method, payment_status, reference_number, notes) VALUES
(1, 1, 175000.00, '2024-02-01', 'bank_transfer', 'paid', 'TXN123456789', 'First milestone payment'),
(1, 1, 175000.00, '2024-03-20', 'bank_transfer', 'paid', 'TXN123456790', 'Final payment'),
(2, 2, 75000.00, '2024-02-15', 'jazzcash', 'paid', 'JC987654321', 'Monthly retainer'),
(2, 2, 75000.00, '2024-03-15', 'jazzcash', 'paid', 'JC987654322', 'Monthly retainer'),
(3, 3, 250000.00, '2024-03-10', 'bank_transfer', 'paid', 'TXN555666777', 'Initial payment'),
(3, 3, 250000.00, '2024-06-30', 'bank_transfer', 'unpaid', NULL, 'Final payment pending'),
(4, 4, 375000.00, '2024-02-01', 'cheque', 'paid', 'CHQ001234', 'Advance payment'),
(4, 4, 375000.00, '2024-05-20', 'cheque', 'unpaid', NULL, 'Completion payment'),
(5, 5, 200000.00, '2024-04-05', 'easypaisa', 'paid', 'EP123456789', 'Project initiation'),
(6, 6, 200000.00, '2024-04-20', 'bank_transfer', 'paid', 'TXN777888999', 'Complete payment');

-- Insert Expenses
INSERT INTO expenses (category, description, amount, expense_date, payment_method, approved_by) VALUES
('utilities', 'Monthly electricity bill for office', 25000.00, '2024-01-31', 'bank_transfer', 1),
('internet', 'Office internet connection - PTCL', 8000.00, '2024-01-31', 'bank_transfer', 1),
('rent', 'Monthly office rent - Johar Town', 120000.00, '2024-01-31', 'bank_transfer', 1),
('software', 'Adobe Creative Suite subscription', 15000.00, '2024-02-01', 'card', 1),
('office_supplies', 'Stationery and office supplies', 12000.00, '2024-02-05', 'cash', 3),
('transport', 'Client meeting fuel expenses', 5000.00, '2024-02-10', 'cash', 4),
('food', 'Team lunch - project milestone celebration', 8000.00, '2024-02-15', 'cash', 3),
('equipment', 'New laptop for developer', 180000.00, '2024-02-20', 'bank_transfer', 1),
('marketing', 'Google Ads campaign', 30000.00, '2024-03-01', 'card', 1),
('utilities', 'Monthly electricity bill for office', 28000.00, '2024-02-28', 'bank_transfer', 1);

-- Insert Salary Payments
INSERT INTO salary_payments (employee_id, salary_month, salary_year, amount, payment_date, payment_method, reference_number) VALUES
(1, 1, 2024, 85000.00, '2024-01-31', 'bank_transfer', 'SAL202401001'),
(2, 1, 2024, 65000.00, '2024-01-31', 'bank_transfer', 'SAL202401002'),
(3, 1, 2024, 95000.00, '2024-01-31', 'bank_transfer', 'SAL202401003'),
(4, 1, 2024, 55000.00, '2024-01-31', 'bank_transfer', 'SAL202401004'),
(5, 1, 2024, 75000.00, '2024-01-31', 'bank_transfer', 'SAL202401005'),
(6, 1, 2024, 80000.00, '2024-01-31', 'bank_transfer', 'SAL202401006'),
(7, 1, 2024, 60000.00, '2024-01-31', 'bank_transfer', 'SAL202401007'),
(8, 1, 2024, 45000.00, '2024-01-31', 'bank_transfer', 'SAL202401008'),
(1, 2, 2024, 85000.00, '2024-02-29', 'bank_transfer', 'SAL202402001'),
(2, 2, 2024, 65000.00, '2024-02-29', 'bank_transfer', 'SAL202402002'),
(3, 2, 2024, 95000.00, '2024-02-29', 'bank_transfer', 'SAL202402003'),
(4, 2, 2024, 55000.00, '2024-02-29', 'bank_transfer', 'SAL202402004'),
(5, 2, 2024, 75000.00, '2024-02-29', 'bank_transfer', 'SAL202402005'),
(6, 2, 2024, 80000.00, '2024-02-29', 'bank_transfer', 'SAL202402006'),
(7, 2, 2024, 60000.00, '2024-02-29', 'bank_transfer', 'SAL202402007'),
(8, 2, 2024, 45000.00, '2024-02-29', 'bank_transfer', 'SAL202402008');

-- =============================================
-- USEFUL QUERIES FOR DASHBOARD
-- =============================================

-- Total Active Projects
SELECT COUNT(*) as total_active_projects FROM projects WHERE status = 'ongoing';

-- Total Employees
SELECT COUNT(*) as total_employees FROM employees WHERE is_active = TRUE;

-- Total Clients
SELECT COUNT(*) as total_clients FROM clients WHERE is_active = TRUE;

-- Monthly Income (All months with data)
SELECT 
    MONTH(payment_date) as month,
    YEAR(payment_date) as year,
    SUM(amount) as monthly_income
FROM payments 
WHERE payment_status = 'paid' 
GROUP BY MONTH(payment_date), YEAR(payment_date)
ORDER BY year DESC, month DESC;

-- Monthly Expenses (All months with data)
SELECT 
    MONTH(expense_date) as month,
    YEAR(expense_date) as year,
    SUM(amount) as monthly_expenses
FROM expenses 
GROUP BY MONTH(expense_date), YEAR(expense_date)
ORDER BY year DESC, month DESC;

-- Monthly Salary Disbursement (All months with data)
SELECT 
    salary_month,
    salary_year,
    SUM(amount) as total_salaries
FROM salary_payments 
GROUP BY salary_month, salary_year
ORDER BY salary_year DESC, salary_month DESC;

-- =============================================
-- ADDITIONAL USEFUL QUERIES
-- =============================================

-- Project Status Summary
SELECT 
    status,
    COUNT(*) as project_count,
    SUM(budget) as total_budget
FROM projects 
GROUP BY status;

-- Top Paying Clients
SELECT 
    c.name as client_name,
    c.company,
    SUM(p.amount) as total_paid
FROM clients c
JOIN payments p ON c.id = p.client_id
WHERE p.payment_status = 'paid'
GROUP BY c.id, c.name, c.company
ORDER BY total_paid DESC;

-- Employee Salary Summary
SELECT 
    e.name,
    e.designation,
    e.salary as monthly_salary,
    COUNT(sp.id) as months_paid,
    SUM(sp.amount) as total_paid
FROM employees e
LEFT JOIN salary_payments sp ON e.id = sp.employee_id
GROUP BY e.id, e.name, e.designation, e.salary
ORDER BY e.salary DESC;

-- Expense Category Summary
SELECT 
    category,
    COUNT(*) as expense_count,
    SUM(amount) as total_amount
FROM expenses 
GROUP BY category
ORDER BY total_amount DESC;

-- Pending Payments
SELECT 
    p.title as project_title,
    c.name as client_name,
    py.amount,
    py.payment_date,
    py.payment_status
FROM payments py
JOIN projects p ON py.project_id = p.id
JOIN clients c ON py.client_id = c.id
WHERE py.payment_status IN ('unpaid', 'partial')
ORDER BY py.payment_date DESC;

-- =============================================
-- INDEXES FOR BETTER PERFORMANCE
-- =============================================

-- Create indexes for better performance (no need to drop since tables are fresh)
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_projects_client_id ON projects(client_id);
CREATE INDEX idx_payments_status ON payments(payment_status);
CREATE INDEX idx_payments_date ON payments(payment_date);
CREATE INDEX idx_expenses_date ON expenses(expense_date);
CREATE INDEX idx_expenses_category ON expenses(category);
CREATE INDEX idx_salary_payments_month_year ON salary_payments(salary_month, salary_year);
CREATE INDEX idx_employees_active ON employees(is_active);
CREATE INDEX idx_clients_active ON clients(is_active);

-- =============================================
-- END OF SCHEMA
-- =============================================